
import React from "react";
import { Tooltip } from "@mui/material";

const courses = [
  { name: "Juego y Vida Activa", code: "EFS1001", credits: 10, semester: 1, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Fundamentos de la Motricidad Humana y la Educación Física", code: "EFS1002", credits: 10, semester: 1, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Anatomía General", code: "BIO1103", credits: 10, semester: 1, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Atletismo", code: "EFS1003", credits: 5, semester: 2, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Fundamentos de la Actividad Física y la Salud", code: "EFS1004", credits: 10, semester: 2, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Fundamentos de la Educación", code: "EDU1513", credits: 10, semester: 2, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Fútbol y Balonmano", code: "EFS1005", credits: 5, semester: 3, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Desarrollo y Aprendizaje Escolar", code: "EFS1006", credits: 10, semester: 3, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Educación y Sociedad", code: "EDU1514", credits: 10, semester: 3, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Expresión Corporal y Folclor", code: "EFS1007", credits: 5, semester: 4, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Psicología del Ejercicio", code: "BIO1104", credits: 10, semester: 4, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Aprendizaje y Desarrollo del Escolar", code: "EDU1515", credits: 10, semester: 4, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Entrenamiento Deportivo Escolar", code: "EFS1008", credits: 5, semester: 5, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Didáctica de la Educación Física I", code: "EFS1009", credits: 5, semester: 5, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Curriculum", code: "EDU1516", credits: 10, semester: 5, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Natación y Gimnasia", code: "EFS1010", credits: 5, semester: 6, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Básquetbol y Voleibol", code: "EFS1011", credits: 5, semester: 6, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Evaluación para el Aprendizaje", code: "EDU1517", credits: 10, semester: 6, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Actividad Física y Salud", code: "EFS1012", credits: 5, semester: 7, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Nutrición y Alimentación para la Actividad Física", code: "EFS1013", credits: 5, semester: 7, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Diversidad e Inclusión en Educación", code: "EDU1518", credits: 10, semester: 7, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Seminario de Investigación en Educación Física I", code: "EFS1014", credits: 10, semester: 8, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Dimensión Ética de la Profesión Docente", code: "EDU1519", credits: 10, semester: 8, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Salud Pública para la Vida Activa y Deportiva", code: "EFS1017", credits: 10, semester: 9, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Recreación en Ambientes Naturales", code: "EFS1020", credits: 5, semester: 9, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Gestión y Liderazgo en el Aula", code: "EDU1520", credits: 10, semester: 9, type: "Curso de formación básica de la Licenciatura", color: "bg-pink-200" },
  { name: "Seminario de Investigación en Educación Física II", code: "EFS1015", credits: 10, semester: 10, type: "Curso propio de Licenciatura", color: "bg-teal-200" },
  { name: "Proyectos Educativos Escolares", code: "EFS1019", credits: 10, semester: 10, type: "Curso propio de Licenciatura", color: "bg-teal-200" }
];

const semesters = Array.from({ length: 10 }, (_, i) => i + 1);

export default function MallaInteractiva() {
  return (
    <div className="min-h-screen p-6 bg-gradient-to-r from-green-100 to-blue-100">
      <h1 className="text-3xl font-bold text-center mb-8 text-sky-800">
        Malla Interactiva - Educación Física y Salud
      </h1>
      <div className="grid grid-cols-10 gap-4 overflow-x-auto">
        {semesters.map((sem) => (
          <div key={sem} className="space-y-4">
            <h2 className="text-center font-semibold text-sky-700">
              Semestre {sem}
            </h2>
            {courses
              .filter((c) => c.semester === sem)
              .map((course) => (
                <Tooltip
                  key={course.code}
                  title={
                    <div className="text-sm">
                      <p><strong>Código:</strong> {course.code}</p>
                      <p><strong>Créditos:</strong> {course.credits} CR</p>
                      <p><strong>Tipo:</strong> {course.type}</p>
                    </div>
                  }
                  arrow
                  placement="right"
                >
                  <div
                    className={`p-2 rounded-lg shadow-md cursor-pointer ${course.color} hover:scale-105 transition`}
                  >
                    <p className="text-xs font-medium text-gray-800 text-center">
                      {course.name}
                    </p>
                  </div>
                </Tooltip>
              ))}
          </div>
        ))}
      </div>
    </div>
  );
}
